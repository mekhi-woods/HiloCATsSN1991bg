import os
import numpy as np
import requests
import json
import matplotlib.pyplot as plt

def dict_unpacker(path, delimiter=', '):
    with open(path, 'r') as f:
        hdr = f.readline()[:-1].split(delimiter)

    data = np.genfromtxt(path, delimiter=delimiter, dtype=str, skip_header=1)
    if len(data) == 0:
        return {}
    temp_objs = {}
    for i in range(len(data[:, 0])):
        obj = data[:, 0][i]
        temp_objs.update({obj: {}})
        for j in range(len(hdr)):
            temp_objs[obj].update({hdr[j]: data[i, j]})
    return temp_objs


if __name__ == '__main__':
    submit = True

    atlas_txt = dict_unpacker('atlas_saved.txt')

    print('Requesting the following from ZTF...')
    for tar in atlas_txt:
        print('---------------------------------------')
        ra = atlas_txt[tar]['ra']
        dec = atlas_txt[tar]['dec']
        jds = float(atlas_txt[tar]['MJDs']) + 2400000 # MJD to JD
        jde = float(atlas_txt[tar]['MJDe']) + 2400000

        if submit:
            cmd = f"wget --http-user=ztffps --http-passwd=dontgocrazy! -O log.txt \"https://ztfweb.ipac.caltech.edu/cgi-bin/requestForcedPhotometry.cgi?ra={ra}&dec={dec}&jdstart={jds}&jdend={jde}&email={'mekhidw@hawaii.edu'}&userpass={'wxdk286'}\""
            # print(cmd)
            results = os.system(cmd)

            print('RA: '+str(ra)+', DEC: '+str(dec)+', '+str(jds)+'-'+str(jde)+', Status: '+str(results))
        # break



   
